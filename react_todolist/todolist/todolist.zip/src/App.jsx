import React from 'react';
import './App.css';
import Todo from './pages/Todo';

function App() {
  return (
    <div>
      <Todo></Todo>
    </div>
  );
}

export default App;
